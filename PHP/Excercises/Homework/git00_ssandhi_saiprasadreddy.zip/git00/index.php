
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
	 <link rel="stylesheet" type="style/main.css" href="main.css">
    <title>Picosite : Home</title>
</head>
<body>
    <header>
        <h1>Picosite : Home</h1>
        <nav id="Head">
        </nav>
    </header>
    <main></main>
</body>
</html>